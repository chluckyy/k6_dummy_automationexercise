import http from 'k6/http';
import { check } from 'k6';

export let options = {
  stages: [
    { duration: '10s', target: 10 },  // tahap awal: naik ke 10 VUs
    { duration: '20s', target: 50 },  // tahan 50 VUs selama 20 detik
    { duration: '10s', target: 0 },   // turun kembali ke 0
  ],
  thresholds: {
    http_req_duration: ['p(95)<500'],  // 95% dari request harus selesai < 500ms
    http_req_failed: ['rate<0.01'],    // error rate harus < 1%
  },
};

export default function () {
  const res = http.get('https://automationexercise.com/api/productsList');

  check(res, {
    'status is 200': (r) => r.status === 200,
    'response has content': (r) => r.body && r.body.length > 0,
    'contains "products"': (r) => r.body.includes('products'),
  });
}