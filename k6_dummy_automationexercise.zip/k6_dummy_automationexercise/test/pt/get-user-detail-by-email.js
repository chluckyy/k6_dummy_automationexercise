import http from 'k6/http';
import { check, sleep } from 'k6';

export let options = {
  vus: 20,             // jumlah virtual users
  duration: '20s',     // durasi pengujian
  thresholds: {
    http_req_duration: ['p(95)<1000'],  // 95% request harus < 1000ms
    http_req_failed: ['rate<0.01'],     // error rate < 1%
  },
};

export default function () {
  const email = 'testuser@example.com'; // ganti dengan email user yang valid
  const url = `https://automationexercise.com/api/getUserDetailByEmail?email=${email}`;

  let res = http.get(url);

  check(res, {
    'status is 200': (r) => r.status === 200,
    'response contains user detail': (r) => r.body.includes('user'), // asumsi response ada field user
  });

  sleep(1); // jeda antar request
}
