import http from 'k6/http';
import { check, sleep } from 'k6';

export let options = {
  vus: 25,             // jumlah virtual users
  duration: '20s',     // durasi pengujian
  thresholds: {
    http_req_duration: ['p(95)<800'],  // 95% request < 800ms
    http_req_failed: ['rate<0.01'],    // error rate < 1%
  },
};

export default function () {
  const url = 'https://automationexercise.com/api/brandsList';

  let res = http.get(url);

  check(res, {
    'status is 200': (r) => r.status === 200,
    'response contains "brands"': (r) => r.body.includes('brands'), // asumsi response berisi field 'brands'
  });

  sleep(1); // delay antar request
}
