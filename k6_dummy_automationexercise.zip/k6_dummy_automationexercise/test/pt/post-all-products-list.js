import http from 'k6/http';
import { check } from 'k6';

export default function () {
  const url = 'https://automationexercise.com/api/productsList';
  let payload = JSON.stringify({});

  let res = http.post(url, payload, {
    headers: { 'Content-Type': 'application/json' },
  });

  check(res, {
    'status is 405': (r) => r.status === 405,
    'error message shown': (r) => r.body.includes('not supported'),
  });
}
