import http from 'k6/http';
import { check } from 'k6';

export let options = {
  stages: [
    { duration: '10s', target: 10 },   // pemanasan: naik ke 10 user
    { duration: '15s', target: 50 },   // naik cepat ke 50 user
    { duration: '15s', target: 100 },  // dorong ke 100 user
    { duration: '20s', target: 150 },  // puncak stres
    { duration: '10s', target: 0 },    // turunkan semua user
  ],
  thresholds: {
    http_req_failed: ['rate<0.05'],          // error harus < 5%
    http_req_duration: ['p(95)<1000'],       // 95% request harus selesai < 1000ms
  },
};

export default function () {
  const res = http.get('https://automationexercise.com/api/productsList');

  check(res, {
    'status is 200': (r) => r.status === 200,
    'body contains "products"': (r) => r.body.includes('products'),
  });
}
