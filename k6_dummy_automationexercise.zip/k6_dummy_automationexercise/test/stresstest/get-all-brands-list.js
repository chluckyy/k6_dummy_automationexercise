import http from 'k6/http';
import { check } from 'k6';

export let options = {
  stages: [
    { duration: '10s', target: 20 },    // pemanasan
    { duration: '15s', target: 50 },    // naik sedang
    { duration: '15s', target: 100 },   // beban berat
    { duration: '20s', target: 200 },   // puncak stres
    { duration: '10s', target: 0 },     // turunkan user
  ],
  thresholds: {
    http_req_failed: ['rate<0.05'],         // < 5% dari total request boleh gagal
    http_req_duration: ['p(95)<1200'],      // 95% dari request harus < 1200ms
  },
};

export default function () {
  const res = http.get('https://automationexercise.com/api/brandsList');

  check(res, {
    'status is 200': (r) => r.status === 200,
    'contains "brands" in response': (r) => r.body.includes('brands'), // asumsi field 'brands' ada
  });
}
