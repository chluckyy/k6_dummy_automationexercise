import http from 'k6/http';
import { check } from 'k6';

export let options = {
  stages: [
    { duration: '10s', target: 20 },    // pemanasan: 20 user
    { duration: '15s', target: 50 },    // naik ke 50 user
    { duration: '15s', target: 100 },   // beban sedang
    { duration: '20s', target: 200 },   // puncak stres
    { duration: '10s', target: 0 },     // turunkan semua user
  ],
  thresholds: {
    http_req_failed: ['rate<0.05'],         // <5% request boleh gagal
    http_req_duration: ['p(95)<1200'],      // 95% request < 1200ms
  },
};

export default function () {
  const email = 'testuser@example.com'; // Ganti dengan email valid di sistem
  const url = `https://automationexercise.com/api/getUserDetailByEmail?email=${email}`;

  let res = http.get(url);

  check(res, {
    'status is 200': (r) => r.status === 200,
    'contains user detail': (r) => r.body.includes('user') || r.body.includes('email'),
  });
}
